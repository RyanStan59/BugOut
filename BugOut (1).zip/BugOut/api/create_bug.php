<?php
session_start();
require_once __DIR__ . "/db.php";

if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed.");
}

$title = trim($_POST["title"] ?? "");
$description = trim($_POST["description"] ?? "");
$severity = trim($_POST["priority"] ?? ""); // your dropdown

// Assume user is logged in
$created_by = $_SESSION["user_id"] ?? 1; // fallback if session not set

if ($title === "" || $description === "" || $severity === "") {
    die("Please fill in all fields.");
}

// default values
$status = "Open";
$assigned_to = NULL;

$sql = "INSERT INTO bugs (title, description, severity, status, created_by, assigned_to)
        VALUES (?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("SQL prepare failed: " . $conn->error);
}

$stmt->bind_param("ssisii", $title, $description, $severity, $status, $created_by, $assigned_to);

if ($stmt->execute()) {
    header("Location: ../pages/bugs.html");
    exit;
} else {
    die("Error saving bug: " . $stmt->error);
}
?>